﻿namespace calculation.Models
{
    public class calc
    { public int n1 { get; set; }
        public int n2 { get; set; }
        public int result { get; set; }

    }
}
