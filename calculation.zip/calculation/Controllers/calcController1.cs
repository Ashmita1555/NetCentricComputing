﻿using calculation.Models;
using Microsoft.AspNetCore.Mvc;

namespace calculation.Controllers
{
    public class calcController1 : Controller
    {
        public IActionResult Index()
        {
            return View( new calc());
        }
        [HttpPost]
        //get:cal
        public ActionResult Index (calc c,string calculate)
        {
            if(calculate=="add")
            {
                c.result=c.n1+c.n2;
            }
            if (calculate == "min")
            {
                c.result = c.n1 - c.n2;
            }
            if (calculate == "mul")
            {
                c.result = c.n1 * c.n2;
            }
            if (calculate == "div")
            {
                c.result = c.n1 / c.n2;
            }
            return View();
        }
    }
}
